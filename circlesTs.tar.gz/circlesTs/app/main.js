"use strict";
var core_1 = require('@angular/core');
var platform_browser_dynamic_1 = require('@angular/platform-browser-dynamic');
var app_component_1 = require('./app.component');
platform_browser_dynamic_1.bootstrap(app_component_1.CanvasComponent, [
    core_1.provide('canvasWidth', { useValue: 900 }),
    core_1.provide('canvasHeight', { useValue: 500 })
]);
//# sourceMappingURL=main.js.map