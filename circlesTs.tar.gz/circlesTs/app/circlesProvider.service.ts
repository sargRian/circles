import { Injectable } from '@angular/core';
import { Circle } from './circle.object';

@Injectable()
export class CirclesProvider {
    sourceCircles: Circle[];
    circles: Circle[];
    pairs: any[];


    constructor() {
        this.sourceCircles = [];
        for (let i=0; i<50; i++){
            var x: number = this.randInt(900);
            var y: number = this.randInt(500);
            var radius: number = this.randInt(100) + 10;

            var deltaX: number = this.randInt(5) - 2;
            var deltaY: number = this.randInt(5) - 2;

            this.sourceCircles.push(new Circle(x, y, radius, deltaX, deltaY));
            this.pairs = [];
            for (let i = 0; i < this.sourceCircles.length - 1; i++) {
                for (let j = i ; j < this.sourceCircles.length - 1; j++){
                    this.pairs.push([this.sourceCircles[i], this.sourceCircles[j + 1]]);
                }
            }
        }
    }

    update(): void{
        for (const sourceCircle of this.sourceCircles) {
            this.moveCircle(sourceCircle);
        }
        this.circles = [];
        for (const [left, right] of this.pairs) {
            const distance: number = this.calculateDistanceBetweenCircles(left, right);
            const overlap: number = distance - left.radius - right.radius;
            const newDeltaX: number = left.deltaX + right.deltaX;
            const newDeltaY: number = left.deltaY + right.deltaY;
            if (overlap < 0) {
                // midpoint = average of the two coordinates
                const midX: number = (left.x + right.x) / 2;
                const midY: number = (left.y + right.y) / 2;
                var colissionCircle = new Circle(midX, midY, (-1 * overlap / 2), newDeltaX, newDeltaY);
                if (colissionCircle !== null){
                    this.circles.push(colissionCircle);
                }
            }
        }
    }

    moveCircle(circle: Circle): void {
            // Move the circle on the x axis according to it's deltaX
            circle.x += circle.deltaX  * (this.randInt(100)*1.2)/1000;
            // If the circle is leaving the frame on the x axis, reverse it's movement
            if(circle.x >= 900 || circle.x <= 0 ) {
                circle.deltaX = circle.deltaX * -1
            }
            // Move the circle on the x axis according to it's deltaX
            circle.y += circle.deltaY * (this.randInt(100)*1.2)/1000;
            // If the circle is leaving the frame on the y axis, reverse it's movement            
            if(circle.y >= 500 || circle.y <= 0 ) {
                circle.deltaY = circle.deltaY * -1
            }
    }

    calculateDistanceBetweenCircles(circle1: Circle, circle2: Circle): number{
        return Math.sqrt(
            (circle2.x - circle1.x) ** 2 +
            (circle2.y - circle1.y) ** 2
        );
    }

    randInt(max: number): number {
        return Math.floor(Math.random() * max);
    }
}