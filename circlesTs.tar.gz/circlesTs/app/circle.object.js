"use strict";
var Circle = (function () {
    function Circle(x, y, radius, deltaX, deltaY) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.deltaX = deltaX;
        this.deltaY = deltaY;
    }
    return Circle;
}());
exports.Circle = Circle;
//# sourceMappingURL=circle.object.js.map