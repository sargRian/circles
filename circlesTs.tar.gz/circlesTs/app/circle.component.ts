import { Component } from '@angular/core';

@Component({
    selector: '[mb-circle]',
    inputs: ['circle'],
    template: `
        <svg:circle [attr.cx]="circle.x"
                    [attr.cy]="circle.y"
                    [attr.r]="circle.radius" 
                                             />
        `,
        styles: [`circle{
                    fill: rgba(200, 10, 5, 0.5);
                }`]
})
export class CircleComponent { }