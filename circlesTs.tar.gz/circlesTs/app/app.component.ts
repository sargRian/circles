import { Component } from '@angular/core';
import { CircleComponent } from './circle.component'
import { CirclesProvider } from './circlesProvider.service'

@Component({
    selector: 'mb-canvas',
    template: `
        <svg [attr.viewBox]="getViewBox()"
                preserveAspectRatio="xMidYMid meet"
                (click)="toggleRunning()">
            <svg:g mb-circle
                *ngFor="let circle of circlesToDraw.circles"
                [circle]="circle" />
        </svg>
        `,
        styleUrls: ['./app/app.component.css'],
        directives: [CircleComponent],
        providers: [CirclesProvider]

})
export class CanvasComponent {
    circlesToDraw: any;
    width: number;
    height: number;
    running: boolean;

    constructor(circles: CirclesProvider) {
        this.circlesToDraw = circles;
        console.log(circles);
        this.width = 900;
        this.height = 500;

    }
    
    ngOnInit() {
        this.running = true;
        this.animationFrame();
    }

    ngOnDestroy() {
        this.running = false;
    }

    toggleRunning() {
        this.running = !this.running;
        if (this.running) {
            this.animationFrame();
        }
    }

    animationFrame() {
        this.circlesToDraw.update();
        if(this.running) {
            requestAnimationFrame(() => this.animationFrame());
        }
    }

    getViewBox() {
        return `0 0 ${this.width} ${this.height}`;
    }
}