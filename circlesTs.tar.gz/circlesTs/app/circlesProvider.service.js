"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var circle_object_1 = require('./circle.object');
var CirclesProvider = (function () {
    function CirclesProvider() {
        this.sourceCircles = [];
        for (var i = 0; i < 50; i++) {
            var x = this.randInt(900);
            var y = this.randInt(500);
            var radius = this.randInt(100) + 10;
            var deltaX = this.randInt(5) - 2;
            var deltaY = this.randInt(5) - 2;
            this.sourceCircles.push(new circle_object_1.Circle(x, y, radius, deltaX, deltaY));
            this.pairs = [];
            for (var i_1 = 0; i_1 < this.sourceCircles.length - 1; i_1++) {
                for (var j = i_1; j < this.sourceCircles.length - 1; j++) {
                    this.pairs.push([this.sourceCircles[i_1], this.sourceCircles[j + 1]]);
                }
            }
        }
    }
    CirclesProvider.prototype.update = function () {
        for (var _i = 0, _a = this.sourceCircles; _i < _a.length; _i++) {
            var sourceCircle = _a[_i];
            this.moveCircle(sourceCircle);
        }
        this.circles = [];
        for (var _b = 0, _c = this.pairs; _b < _c.length; _b++) {
            var _d = _c[_b], left = _d[0], right = _d[1];
            var distance = this.calculateDistanceBetweenCircles(left, right);
            var overlap = distance - left.radius - right.radius;
            var newDeltaX = left.deltaX + right.deltaX;
            var newDeltaY = left.deltaY + right.deltaY;
            if (overlap < 0) {
                // midpoint = average of the two coordinates
                var midX = (left.x + right.x) / 2;
                var midY = (left.y + right.y) / 2;
                var colissionCircle = new circle_object_1.Circle(midX, midY, (-1 * overlap / 2), newDeltaX, newDeltaY);
                if (colissionCircle !== null) {
                    this.circles.push(colissionCircle);
                }
            }
        }
    };
    CirclesProvider.prototype.moveCircle = function (circle) {
        // Move the circle on the x axis according to it's deltaX
        circle.x += circle.deltaX * (this.randInt(100) * 1.2) / 1000;
        // If the circle is leaving the frame on the x axis, reverse it's movement
        if (circle.x >= 900 || circle.x <= 0) {
            circle.deltaX = circle.deltaX * -1;
        }
        // Move the circle on the x axis according to it's deltaX
        circle.y += circle.deltaY * (this.randInt(100) * 1.2) / 1000;
        // If the circle is leaving the frame on the y axis, reverse it's movement            
        if (circle.y >= 500 || circle.y <= 0) {
            circle.deltaY = circle.deltaY * -1;
        }
    };
    CirclesProvider.prototype.calculateDistanceBetweenCircles = function (circle1, circle2) {
        return Math.sqrt(Math.pow((circle2.x - circle1.x), 2) +
            Math.pow((circle2.y - circle1.y), 2));
    };
    CirclesProvider.prototype.randInt = function (max) {
        return Math.floor(Math.random() * max);
    };
    CirclesProvider = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [])
    ], CirclesProvider);
    return CirclesProvider;
}());
exports.CirclesProvider = CirclesProvider;
//# sourceMappingURL=circlesProvider.service.js.map