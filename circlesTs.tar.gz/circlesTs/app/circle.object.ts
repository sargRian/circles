export class Circle {
    x: number;
    y: number;
    radius: number;
    deltaX: number;
    deltaY: number;


    constructor (x:number, y:number, radius:number, deltaX:number, deltaY:number){
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.deltaX = deltaX;
        this.deltaY = deltaY;
    }

}