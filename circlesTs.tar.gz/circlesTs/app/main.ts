import { provide } from '@angular/core';
import { bootstrap } from '@angular/platform-browser-dynamic';
import { CanvasComponent } from './app.component';

bootstrap(CanvasComponent, [
    provide('canvasWidth', {useValue: 900}),
    provide('canvasHeight', {useValue: 500})
]);